package com.ssafy.test.controller.board;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.board.BoardImg;
import com.ssafy.test.model.service.board.BoardImgService;

@RestController
@RequestMapping("/board/img")
public class BoardImgController {
	BoardImgService boardImgService;

	public BoardImgController(BoardImgService boardImgService) {
		this.boardImgService = boardImgService;
	}
	
	@PostMapping("/regist")
	public ResponseEntity<?> setBoardImg(@RequestBody BoardImg boardImg) {
		try {
			int result = boardImgService.setImgUrl(boardImg);
			if(result > 0) {
				return ResponseEntity.ok().body("success set img url!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!");
			}
		}catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@GetMapping("/{board_id}")
	public ResponseEntity<?> getBoardImg(@PathVariable int board_id) {
		try {
			BoardImg result = boardImgService.getImgUrl(board_id);
			return ResponseEntity.ok(result);
		}catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@DeleteMapping("/{board_id}")
	public ResponseEntity<?> deleteBoardImg(@PathVariable int board_id) {
		try {
			int result = boardImgService.deleteImg(board_id);
			if(result > 0) {
				return ResponseEntity.ok().body("success delete img url!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
