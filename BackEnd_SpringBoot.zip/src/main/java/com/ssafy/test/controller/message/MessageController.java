package com.ssafy.test.controller.message;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.message.MessageDto;
import com.ssafy.test.model.service.message.MessageService;

@RestController
@RequestMapping("/message")
public class MessageController {

	MessageService messageService;

	public MessageController(MessageService messageService) {
		this.messageService = messageService;
	}

	@PostMapping("/list")
	public ResponseEntity<?> getList(@RequestBody MessageDto message){


		try {
			List<MessageDto> list = messageService.getMessages(message);
			return ResponseEntity.ok().body(list);
		}
		catch(Exception e) {
			return exceptionHandling(e);
		}
	}

	@PostMapping("/send")
	public ResponseEntity<?> send(@RequestBody MessageDto message){

		try {
			messageService.send(message);
			return ResponseEntity.ok().body("message send compelete!");
		}
		catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/people")
	public ResponseEntity<?> people(@RequestBody MessageDto messageUser){

		try {
			List<String> list = messageService.people(messageUser.getSendUser());
			return ResponseEntity.ok().body(list);
		}
		catch(Exception e) {
			return exceptionHandling(e);
		}
	}


	private ResponseEntity<String> exceptionHandling(Exception e){
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: "+e.getMessage());
	}
}
