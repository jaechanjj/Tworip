package com.ssafy.test.controller.user;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.util.ShaUtil;
import com.ssafy.test.model.dto.user.User;
import com.ssafy.test.model.service.user.UserService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/user")

public class UserController {
	private UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody User user) {
		try {
			User loginUser = userService.login(user.getUserId());
			
		
			if(loginUser == null) return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Incorrect ID input!");
			else {
				String pw = ShaUtil.sha256Encode(user.getUserPass(),loginUser.getSalt());
				if(loginUser.getUserPass().equals(pw)) {
					System.out.println("로그인 성공!");
					return ResponseEntity.ok(loginUser);
				} else {
					System.out.println("비밀번호를 다시 입력해주세요.");
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Incorrect PW input!");
				}
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
//	@GetMapping("/logout")
//	public ResponseEntity<?> logout(HttpSession session) {
//		try {
//			session.invalidate();
//			System.out.println("로그아웃 완료!");
//			return ResponseEntity.ok().body("success logout!");
//		} catch (Exception e) {
//			return exceptionHandling(e);
//		}
//	}
	
	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody User user) {
		try {
			String salt = ShaUtil.getSalt();
			String pw = ShaUtil.sha256Encode(user.getUserPass(),salt);
			user.setUserPass(pw);
			user.setSalt(salt);
			
			int result = userService.register(user);
			
			if(result > 0) return ResponseEntity.ok().body("success register!");
			else return ResponseEntity.internalServerError().build();
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/delete")
	public ResponseEntity<?> delete(@RequestBody User user) {
		try {
			int result = userService.delete(user.getUserId());
			if(result > 0) return ResponseEntity.ok().body("success delete!");
			else return  ResponseEntity.internalServerError().build();
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PutMapping("/update")
	public ResponseEntity<?> update(@RequestBody User user) {
		try {
			int result = userService.update(user);
			if(result > 0) {
				System.out.println("회원 정보 변경 완료!");
				User updateUser = userService.login(user.getUserId());
				return ResponseEntity.ok(updateUser);
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@GetMapping("/list")
	public ResponseEntity<?> getUserList() {
		try {
			List<User> userList = userService.getList();
			
			if(!userList.isEmpty() && userList != null) {
				return ResponseEntity.ok(userList);
			}
			else return ResponseEntity.noContent().build();
		}catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PutMapping("/update-password")
	public ResponseEntity<?> updatePassword(@RequestBody User user) {
		try {
			User loginUser = userService.login(user.getUserId());
			String salt = loginUser.getSalt();
			String newPassword =  ShaUtil.sha256Encode(user.getUserPass(),salt);
			user.setUserPass(newPassword);
			int result = userService.updatePwd(user);
			
			if(result > 0) {
				System.out.println("비밀번호 변경 성공!");
				return ResponseEntity.ok().body("success update password!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/user-info")
	public ResponseEntity<?> getUserInfo(@RequestBody User user) {
		try {
			String findUserId = user.getUserId();
			User foundUser = userService.getUserInfo(findUserId);
			
			if(foundUser != null) {
				System.out.println("회원 정보 조회 : " + findUserId);
				return ResponseEntity.ok(foundUser);
			} else {
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Not Found User!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
