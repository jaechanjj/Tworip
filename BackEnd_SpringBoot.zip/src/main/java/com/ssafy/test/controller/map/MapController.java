package com.ssafy.test.controller.map;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.map.MapDto;
import com.ssafy.test.model.service.map.MapService;

@RestController
@RequestMapping("/map")
public class MapController {
	
	private MapService mapService;
	
	public MapController(MapService mapService) {
		this.mapService = mapService;
	}

	@GetMapping("/list/{area}/{type}")
	public ResponseEntity<?> getMapList(@PathVariable(value = "area") String area, @PathVariable(value = "type") String type) {
		try {
			Map<String, Integer> listKind = new HashMap<>();
			listKind.put("area", Integer.parseInt(area));
			listKind.put("type", Integer.parseInt(type));
			
			List<MapDto> mapList = mapService.getList(listKind);
			
			if(!mapList.isEmpty() && mapList != null) return ResponseEntity.ok(mapList);
			else return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@GetMapping("/{search}")
	public ResponseEntity<?> getSearchList(@PathVariable String search) {
		try {
			List<MapDto> mapList = mapService.getSearchList(search);
			
			if(!mapList.isEmpty() && mapList != null) return ResponseEntity.ok(mapList);
			else return ResponseEntity.noContent().build();
			
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
