package com.ssafy.test.controller.board;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.board.BoardComment;
import com.ssafy.test.model.dto.user.User;
import com.ssafy.test.model.service.board.BoardCommentService;
import com.ssafy.test.model.service.board.BoardCommentServiceImpl;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/board/comment")
public class BoardCommentController {
	BoardCommentServiceImpl boardCommentService;

	public BoardCommentController(BoardCommentServiceImpl boardCommentService) {
		this.boardCommentService = boardCommentService;
	}
	
	@PostMapping("{board_id}")
	public ResponseEntity<?> postComment(@PathVariable int board_id, @RequestBody BoardComment boardComment) {		
		try {
			boardComment.setBoardNo(board_id);
			int result = boardCommentService.postComment(boardComment);
			
			if(result > 0) {
				System.out.println("댓글 등록 성공!");
				return ResponseEntity.ok().body("success post comment!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		}catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PutMapping("{comment_id}")
	public ResponseEntity<?> putComment(@PathVariable int comment_id, @RequestBody BoardComment boardComment) {
		try {
			boardComment.setId(comment_id);
			int result = boardCommentService.putComment(boardComment);
			
			if(result > 0) {
				System.out.println("댓글 수정 성공!!");
				return ResponseEntity.ok().body("success put comment!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Incorrect comment ID entered!");
			}
		} catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@DeleteMapping("{comment_id}")
	public ResponseEntity<?> deleteComment(@PathVariable int comment_id) {
		try {
			int result = boardCommentService.deleteComment(comment_id);
			
			if(result > 0) {
				System.out.println("댓글 삭제 성공!!");
				return ResponseEntity.ok().body("success delete comment!!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Incorrect comment ID entered!");
			}
		} catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@GetMapping("{board_id}")
	public ResponseEntity<?> getListComment(@PathVariable int board_id) {
		try {
			List<BoardComment> commentList = boardCommentService.getCommentList(board_id);
			
			if(commentList != null && !commentList.isEmpty()) {
				System.out.println("댓글 목록 가져오기 성공!!");
				return ResponseEntity.ok(commentList);
			} else {
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No Comment List!");
			}
		} catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
