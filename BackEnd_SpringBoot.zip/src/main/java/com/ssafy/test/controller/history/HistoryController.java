package com.ssafy.test.controller.history;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.follow.Follow;
import com.ssafy.test.model.dto.tripHistory.TripHistory;
import com.ssafy.test.model.dto.user.User;
import com.ssafy.test.model.service.history.HistoryService;
import com.ssafy.test.model.service.history.HistoryServiceImpl;

@RestController
@RequestMapping("/history")
public class HistoryController {
	HistoryService historyService;

	public HistoryController(HistoryService historyService) {
		this.historyService = historyService;
	}
	
	@PostMapping("/get-list")
	public ResponseEntity<?> getList(@RequestBody User user) {
		try {
			List<TripHistory> historyList = historyService.getHistory(user.getUserId());
			return ResponseEntity.ok(historyList);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/change")
	public ResponseEntity<?> changeStatus(@RequestBody TripHistory tripHistory) {

		try {
			historyService.changeStatus(tripHistory);
			return ResponseEntity.ok().body("success change history status!");
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/search")
	public ResponseEntity<?> search(@RequestBody TripHistory tripHistory) {

		try {
			List<TripHistory> user = historyService.search(tripHistory);
			System.out.println(user);
			return ResponseEntity.ok().body(user);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/get-curTrip")
	public ResponseEntity<?> getCurTrip(@RequestBody User user) {
		try {
			List<TripHistory> historyList = historyService.getCurTrip(user.getUserId());
			return ResponseEntity.ok(historyList);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
