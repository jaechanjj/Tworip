package com.ssafy.test.controller.talk;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.talk.Talk;
import com.ssafy.test.model.service.talk.TalkService;

@RestController
@RequestMapping("/talk")
public class TalkController {
	TalkService talkService;

	public TalkController(TalkService talkService) {
		this.talkService = talkService;
	}
	
	@PostMapping("/regist")
	public ResponseEntity<?> registTalk(@RequestBody Talk talk) {
		try {
			talk.setUserId("ssafy");
			int result = talkService.registTalk(talk);
			
			if(result > 0) {
				return ResponseEntity.ok().body("success regist talk!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@GetMapping("/get-list")
	public ResponseEntity<?> registTalk() {
		try {
			List<Talk> talkList = talkService.getTalkList();
			
			if(talkList != null && !talkList.isEmpty()) {
				return ResponseEntity.ok(talkList);
			} else {
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No Content!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@GetMapping("/{talk_id}")
	public ResponseEntity<?> getDetailTalk(@PathVariable int talk_id) {
		try {
			Talk talk = talkService.getDetailTalk(talk_id);
			
			if(talk != null) {
				return ResponseEntity.ok(talk);
			} else {
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No Content!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@DeleteMapping("/{talk_id}")
	public ResponseEntity<?> deleteTalk(@PathVariable int talk_id) {
		try {
			int result = talkService.deleteTalk(talk_id);
			
			if(result > 0) {
				return ResponseEntity.ok().body("success delete talk!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PutMapping("/{talk_id}")
	public ResponseEntity<?> updateTalk(@PathVariable int talk_id, @RequestBody Talk talk) {
		try {
			talk.setArticleNo(talk_id);
			int result = talkService.updateTalk(talk);
			
			if(result > 0) {
				return ResponseEntity.ok().body("success update talk!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
