package com.ssafy.test.controller.board;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.board.BoardLike;
import com.ssafy.test.model.dto.board.BoardLikeResponse;
import com.ssafy.test.model.dto.user.User;
import com.ssafy.test.model.service.board.BoardLikeService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/board/like")
public class BoardLikeController {
	BoardLikeService boardService;

	public BoardLikeController(BoardLikeService boardService) {
		this.boardService = boardService;
	}
	
	@PostMapping("{board_id}")
	public ResponseEntity<?> postLike(@PathVariable int board_id, @RequestBody User loginUser) {
		try {
			BoardLike boardLike = new BoardLike();
			boardLike.setArticleNo(board_id);
			boardLike.setUserId(loginUser.getUserId());
			
			int result = boardService.postLike(boardLike);
			
			if(result > 0) {
				System.out.println("좋아요 등록!");
				return ResponseEntity.ok().body("success post like!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@DeleteMapping("{board_id}")
	public ResponseEntity<?> deleteLike(@PathVariable int board_id, @RequestBody User loginUser) {
		try {
			BoardLike boardLike = new BoardLike();
			boardLike.setArticleNo(board_id);
			boardLike.setUserId(loginUser.getUserId());
			
			int result = boardService.deleteLike(boardLike);
			
			if(result > 0 ) {
				System.out.println("좋아요 취소!");
				return ResponseEntity.ok().body("success delete like!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/get/{board_id}")
	public ResponseEntity<?> getLike(@PathVariable int board_id, @RequestBody User loginUser) {
		try {
			BoardLike boardLike = new BoardLike();
			boardLike.setArticleNo(board_id);
			boardLike.setUserId(loginUser.getUserId());
			
			BoardLike result = boardService.getBoardLike(boardLike);
			
			System.out.println("해당 게시글 좋아요 여부 조회 성공!");
			// 리턴 값이 null이면 프론트에서 좋아요 표시 x , 리턴 값이 객체로 넘어오면 좋아요 표시 O
			return ResponseEntity.ok().body(result);
		} catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping
	public ResponseEntity<?> getLikeList(@RequestBody User loginUser) {
		try {
			
			List<BoardLikeResponse> likeList = boardService.getBoardLikeList(loginUser.getUserId());
			
			System.out.println("로그인한 유저의 좋아요 리스트 조회 성공!");
			return ResponseEntity.ok().body(likeList);
		} catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
