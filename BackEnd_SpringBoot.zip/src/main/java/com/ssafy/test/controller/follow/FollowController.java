package com.ssafy.test.controller.follow;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.follow.Follow;
import com.ssafy.test.model.dto.follow.FollowRes;
import com.ssafy.test.model.service.follow.FollowServiceImpl;


@RestController
@RequestMapping("/follow")
public class FollowController {
	FollowServiceImpl followService;

	public FollowController(FollowServiceImpl followService) {
		this.followService = followService;
	}
	
	@PostMapping("/request")
	public ResponseEntity<?> reqFollow(@RequestBody Follow follow) {
		try {
			System.out.println(follow.getFollowee());
			int result = followService.reqFollow(follow);
			
			if(result > 0) {
				System.out.println("팔로우 요청 : " + follow.getFollower() + "->" + follow.getFollowee());
				return ResponseEntity.ok().body("success reqeust follow!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/get-request")
	public ResponseEntity<?> getReqFollow(@RequestBody Follow follow) {
		try {
			Follow result = followService.getReqFollow(follow);
			if(result != null) {
				System.out.println("팔로우 요청 기록 존재: " + follow.getFollower() + "->" + follow.getFollowee());
			} else {
				System.out.println("팔로우 요청 기록 존재하지 않음");
			}
			return ResponseEntity.ok(result);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/get-list")
	public ResponseEntity<?> getList(@RequestBody Follow follow) {
		try {
			String followee = follow.getFollowee();
			List<Follow> followers = followService.getUserFollow(followee);
			return ResponseEntity.ok(followers);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/get-list/followee")
	public ResponseEntity<?> getListFolloweeWait(@RequestBody Follow follow) {
		try {
			String follower = follow.getFollower();
			List<FollowRes> followWaitList = followService.getReqFolloee(follower);
			return ResponseEntity.ok(followWaitList);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/accept")
	public ResponseEntity<?> acceptFollow(@RequestBody Follow follow) {
		try {
			int result = followService.acceptFollow(follow);
			
			if(result > 0 ) {
				followService.refuseFollow(follow); // 팔로우 수락 후 대기 목록에서 지움
				return ResponseEntity.ok().body("success accept follow!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	@PostMapping("/refuse")
	public ResponseEntity<?> refuseFollow(@RequestBody Follow follow) {
		try {
			int result = followService.refuseFollow(follow);
			
			if(result > 0 ) {
				System.out.println("팔로우 요청 거절!");
				return ResponseEntity.ok().body("success refuse follow!");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
			}
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/get-follower-list")
	public ResponseEntity<?> getUserFollower(@RequestBody Follow follow) {
		try {
			List<FollowRes> followerList = followService.getUserFollower(follow.getFollowee());
			
			return ResponseEntity.ok(followerList);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/get-followee-list")
	public ResponseEntity<?> getUserFollowee(@RequestBody Follow follow) {
		try {
			System.out.println(follow.getFollower());
			List<FollowRes> followeeList = followService.getUserFollowee(follow.getFollower());
			
			return ResponseEntity.ok(followeeList);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	@PostMapping("/check")
	public ResponseEntity<?> checFollow(@RequestBody Follow follow) {
		try {
			Follow isFollow = followService.followCheck(follow);
			return ResponseEntity.ok(isFollow);
		} catch (Exception e) {
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		e.printStackTrace();
		return ResponseEntity.internalServerError().body("Sorry: " + e.getMessage());
	}
}
