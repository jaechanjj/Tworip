package com.ssafy.test.controller.map.triplist;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.board.Board;
import com.ssafy.test.model.dto.comfirmplan.ComfirmPlan;
import com.ssafy.test.model.dto.map.MapDto;
import com.ssafy.test.model.dto.tripplan.TripPlanDto;
import com.ssafy.test.model.dto.user.User;
import com.ssafy.test.model.service.map.MapService;
import com.ssafy.test.model.service.tripplan.TripPlanServcie;


@RestController
@RequestMapping("/map")
public class TripPlanController {

	private TripPlanServcie tripPlanService;

	public TripPlanController(TripPlanServcie tripPlanService) {
		this.tripPlanService = tripPlanService;
	}

	//	등록
	@PostMapping("/triplist/regist")
	public ResponseEntity<?> postPlan(@RequestBody TripPlanDto tripPlanDto) {

		int result = tripPlanService.postPlan(tripPlanDto);

		if(result>0) {
			return ResponseEntity.ok().body("success post trip plan!!");
		}
		else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
		}
	}
	
	@PostMapping("/triplist/list/{userId}")
	public ResponseEntity<?> showList(@PathVariable String userId) {

		List<TripPlanDto> list = tripPlanService.showList(userId);

		if(list != null && list.size()>0) {
			return ResponseEntity.ok().body(list);
		}
		else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
		}
	}
	
	@DeleteMapping("/triplist/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable int id){
		int result = tripPlanService.remove(id);
		
		if(result==1) {
			return ResponseEntity.ok().body("success delete!");
		}
		else {
			return ResponseEntity.internalServerError().build();
		}
	}
	
	
	@PostMapping("/triplist/comfirm")
	public ResponseEntity<?> postOwnPlan(@RequestBody ComfirmPlan comfirmPlan) {

		System.out.println(comfirmPlan);
		int result = tripPlanService.postOwnPlan(comfirmPlan);

		if(result>0) {
			return ResponseEntity.ok().body("success post trip plan!!");
		}
		else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error!!");
		}
	}
	
	
	@GetMapping("triplist/sameplace/{userId}")
	public ResponseEntity<?> samePlaceUser(@PathVariable String userId){
		
		List<String> list = tripPlanService.getsamePlaceUser(userId);
		
		if(list!=null && list.size()>0) {
			return ResponseEntity.ok().body(list);
		}
		else {
			return ResponseEntity.ok().body("");
		}
	}
	
	
	

	
}
