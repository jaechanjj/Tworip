package com.ssafy.test.controller.board;

import java.util.List;

import org.apache.ibatis.annotations.Update;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.test.model.dto.board.Board;
import com.ssafy.test.model.dto.user.User;
import com.ssafy.test.model.service.board.BoardService;
import com.ssafy.test.model.service.board.BoardServiceImpl;

import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/board")
public class BoardController {

	private BoardService boardService;
	 
	public BoardController(BoardService boardService) {
		this.boardService=boardService;
	}
	
	
	@PostMapping("/regist")
	public ResponseEntity<?> regist(@RequestBody Board board){
		boardService.regist(board);
		int result = board.getArticleNo();
		if(result>0) {
			return ResponseEntity.ok(result); // 방금 작성된 게시글 번호 반환
		}
		else {
			return  ResponseEntity.internalServerError().build();		
		}
	}
	
	@DeleteMapping("/delete/{article_no}")
	public ResponseEntity<?> delete(@PathVariable int article_no){
		int result = boardService.delete(article_no);
		
		if(result==1) {
			return ResponseEntity.ok().body("success delete!");
		}
		else {
			return ResponseEntity.internalServerError().build();
		}
	}
	
	
	@PutMapping("/update/{article_no}")
	public ResponseEntity<?> update(@RequestBody Board board, @PathVariable int article_no){
		board.setArticleNo(article_no);
		int result = boardService.update(board);
		
		if(result==1) {
			return ResponseEntity.ok().body("success update!");
		}
		else {
			return ResponseEntity.internalServerError().build();
		}
	}
	
	@GetMapping("/listarticle")
	public ResponseEntity<?> listarticle(){
		List<Board> boards = boardService.listarticle();
		
		if(boards!=null && boards.size()!=0) {
			return ResponseEntity.ok().body(boards);
		}
		else {
			return ResponseEntity.internalServerError().build();
		}
		
	}
	
	@PostMapping("/{articleNo}")
	public ResponseEntity<?> detail(@PathVariable int articleNo, @RequestBody User loginUser){
		Board board = boardService.detail(articleNo);
		
		if(board!=null) {
			if(loginUser != null && !board.getUserId().equals(loginUser.getUserId())) {
				boardService.updateHit(articleNo);
			}
			return ResponseEntity.ok().body(board);
		}
		else {
			return ResponseEntity.internalServerError().build();
		}
		
	}
	
}
