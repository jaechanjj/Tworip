package com.ssafy.test.model.dao.tripplan;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.comfirmplan.ComfirmPlan;
import com.ssafy.test.model.dto.singlecomfirmplan.SingleComfirmPlan;
import com.ssafy.test.model.dto.tripplan.TripPlanDto;
import com.ssafy.test.model.dto.user.User;

@Mapper
public interface TripPlanDao {


	int regist(TripPlanDto tripPlanDto);
	List<TripPlanDto> showList(String userId);
	int remove(int id);
	int postOwnPlan(SingleComfirmPlan tmp);
	List<String> getsamePlaceUser(String userId);
	

}
