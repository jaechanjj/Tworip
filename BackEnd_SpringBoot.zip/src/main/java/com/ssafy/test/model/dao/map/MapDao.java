package com.ssafy.test.model.dao.map;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.map.MapDto;

@Mapper
public interface MapDao {
	List<MapDto> getList(Map<String, Integer> listKind);
	List<MapDto> getSearchList(String keyword);
}
