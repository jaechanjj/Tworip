package com.ssafy.test.model.dto.follow;

public class FollowRes {
	String userId;
	String userName;
	String emailId;
	String domain;
	
	public FollowRes() {}

	public FollowRes(String userId, String userName, String emailId, String domain) {
		this.userId = userId;
		this.userName = userName;
		this.emailId = emailId;
		this.domain = domain;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}

	@Override
	public String toString() {
		return "FollowRes [userId=" + userId + ", userName=" + userName + ", emailId=" + emailId + ", domain=" + domain
				+ "]";
	}
}
