package com.ssafy.test.model.dao.user;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import com.ssafy.test.model.dto.user.User;

@Mapper
public interface UserDao {
	public User login(String userId);
	public int register(User user);
	public int delete(String userId);
	public int update(User user);
	public List<User> getList();
	public int updatePwd(User user);
	public User getUserInfo(String userId);
}
