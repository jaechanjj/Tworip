package com.ssafy.test.model.dto.comfirmplan;

import java.util.List;

public class ComfirmPlan {

	private int id;
	private String tripName;
	private String userId;
	private List<Integer> contentId;
	private String createdAt;
	private int status;
	
	public ComfirmPlan() {}

	public ComfirmPlan(int id, String tripName, String userId, List<Integer> contentId, String createdAt, int status) {
		this.id = id;
		this.tripName = tripName;
		this.userId = userId;
		this.contentId = contentId;
		this.createdAt = createdAt;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTripName() {
		return tripName;
	}

	public void setTripName(String tripName) {
		this.tripName = tripName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<Integer> getContentId() {
		return contentId;
	}

	public void setContentId(List<Integer> contentId) {
		this.contentId = contentId;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ComfirmPlan [id=" + id + ", tripName=" + tripName + ", userId=" + userId + ", contentId=" + contentId
				+ ", createdAt=" + createdAt + ", status=" + status + "]";
	}
}
