package com.ssafy.test.model.dao.message;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.message.MessageDto;

@Mapper
public interface MessageDao {

	List<MessageDto> getMessage(MessageDto message);
	void send(MessageDto message);
	List<String> people(String userId);

}
