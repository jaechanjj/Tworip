package com.ssafy.test.model.dto.board;

public class BoardComment {
	int id;
	String userId;
	String content;
	String createdTime;
	int boardNo;
	
	public BoardComment() {}

	public BoardComment(int id, String userId, String content, String createdTime, int boardNo) {
		this.id = id;
		this.userId = userId;
		this.content = content;
		this.createdTime = createdTime;
		this.boardNo = boardNo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public int getBoardNo() {
		return boardNo;
	}

	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}

	@Override
	public String toString() {
		return "BoardComment [id=" + id + ", userId=" + userId + ", content=" + content + ", createdTime=" + createdTime
				+ ", boardNo=" + boardNo + "]";
	}
}
