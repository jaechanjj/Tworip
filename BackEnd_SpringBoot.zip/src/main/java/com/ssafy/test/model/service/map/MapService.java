package com.ssafy.test.model.service.map;

import java.util.List;
import java.util.Map;

import com.ssafy.test.model.dto.map.MapDto;

public interface MapService {
	List<MapDto> getList(Map<String, Integer> listKind);
	List<MapDto> getSearchList(String keyword);
}
