package com.ssafy.test.model.dao.follow;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.follow.Follow;
import com.ssafy.test.model.dto.follow.FollowRes;

@Mapper
public interface FollowDao {
	public int reqFollow(Follow follow);
	public Follow getReqFollow(Follow follow);
	public List<Follow> getUserFollow(String followee);
	public int acceptFollow(Follow follow);
	public int refuseFollow(Follow follow);
	public List<FollowRes> getUserFollowee(String followee);
	public List<FollowRes> getUserFollower(String followee);
	public Follow followCheck(Follow follow);
	public List<FollowRes> getReqFolloee(String followee);
}
