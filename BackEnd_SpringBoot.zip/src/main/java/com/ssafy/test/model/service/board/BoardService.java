package com.ssafy.test.model.service.board;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.test.model.dto.board.Board;
import com.ssafy.test.model.dto.swear.Swear;


public interface BoardService {

	int regist(Board board);
	List<Board> listarticle();
	Board view(String articleNo);
	int delete(int article_no);
	int update(Board board);
	void updateHit(int articleNo);
	ArrayList<Swear> getSwears();
	Board detail(int articleNo);
}
