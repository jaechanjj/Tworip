package com.ssafy.test.model.service.board;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.board.BoardDao;
import com.ssafy.test.model.dto.board.Board;
import com.ssafy.test.model.dto.swear.Swear;

@Service
public class BoardServiceImpl implements BoardService{

	private BoardDao boardDao;
	
	public BoardServiceImpl(BoardDao boardDao) {
		this.boardDao=boardDao;
	}

	@Override
	public int regist(Board board) {
		return boardDao.regist(board);
	}

	@Override
	public List<Board> listarticle() {
		return boardDao.listarticle();
	}

	@Override
	public Board view(String articleNo) {
		return boardDao.view(articleNo);
	}

	@Override
	public int delete(int articleNo) {
		return boardDao.delete(articleNo);
	}

	@Override
	public int update(Board board) {
		return boardDao.update(board);
	}

	@Override
	public void updateHit(int articleNo) {
		boardDao.updateHit(articleNo);
		
	}

	@Override
	public ArrayList<Swear> getSwears() {
		return boardDao.getSwears();
	}

	@Override
	public Board detail(int articleNo) {
		return boardDao.detail(articleNo);
	}
	
	

}
