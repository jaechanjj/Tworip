package com.ssafy.test.model.dto.board;

public class BoardImg {
	int id;
	int boardId;
	String imgUrl;
	
	public BoardImg() {}

	public BoardImg(int id, int boardId, String imgUrl) {
		this.id = id;
		this.boardId = boardId;
		this.imgUrl = imgUrl;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getBoardId() {
		return boardId;
	}
	public void setBoardId(int boardId) {
		this.boardId = boardId;
	}
	
	public String getImgUrl() {
		return imgUrl;
	}
	
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	@Override
	public String toString() {
		return "BoardImg [id=" + id + ", boardId=" + boardId + ", imgUrl=" + imgUrl + "]";
	}
}
