package com.ssafy.test.model.service.board;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.board.BoardCommentDao;
import com.ssafy.test.model.dto.board.BoardComment;

public interface BoardCommentService  {
	int postComment(BoardComment boardComment);
	int putComment(BoardComment boardComment);
	int deleteComment(int id);
	List<BoardComment> getCommentList(int board_id);
}
