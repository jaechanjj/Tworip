package com.ssafy.test.model.service.chatGpt;

public interface ChatGptService {

}
