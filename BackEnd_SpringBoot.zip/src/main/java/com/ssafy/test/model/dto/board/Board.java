package com.ssafy.test.model.dto.board;

public class Board{

	private int articleNo;
	private String title;
	private String content;
	private int hit;
	private String createdAt;
	private String userId;
	
	public Board(){}

	
	public Board(int articleNo, String title, String content, String userName, int hit, String createdAt,
			String userId) {
		super();
		this.articleNo = articleNo;
		this.title = title;
		this.content = content;
		this.hit = hit;
		this.createdAt = createdAt;
		this.userId = userId;
	}
	
	public Board(String title, String content, String userId) {
		this.title=title;
		this.content=content;
		this.userId=userId;
	}

	public int getArticleNo() {
		return articleNo;
	}

	public void setArticleNo(int articleNo) {
		this.articleNo = articleNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getHit() {
		return hit;
	}

	public void setHit(int hit) {
		this.hit = hit;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUser_id(String userId) {
		this.userId = userId;
	}


	@Override
	public String toString() {
		return "Board [articleNo=" + articleNo + ", title=" + title + ", content=" + content + ", hit=" + hit + ", createdAt=" + createdAt + ", userId=" + userId + "]";
	}



	
	
}
