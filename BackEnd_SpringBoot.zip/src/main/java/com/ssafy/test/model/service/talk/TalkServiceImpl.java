package com.ssafy.test.model.service.talk;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.talk.TalkDao;
import com.ssafy.test.model.dto.talk.Talk;

@Service
public class TalkServiceImpl implements TalkService{
	TalkDao talkDao;

	public TalkServiceImpl(TalkDao talkDao) {
		this.talkDao = talkDao;
	}

	@Override
	public List<Talk> getTalkList() {
		return talkDao.getTalkList();
	}

	@Override
	public int registTalk(Talk talk) {
		return talkDao.registTalk(talk);
	}

	@Override
	public int deleteTalk(int talkId) {
		return talkDao.deleteTalk(talkId);
	}

	@Override
	public int updateTalk(Talk talk) {
		return talkDao.updateTalk(talk);
	}

	@Override
	public Talk getDetailTalk(int talkId) {
		return talkDao.getDetailTalk(talkId);
	}
	
	
}
