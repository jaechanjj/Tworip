package com.ssafy.test.model.service.user;

import java.util.List;

import com.ssafy.test.model.dto.user.User;

public interface UserService {
	public User login(String userId);
	public int register(User user);
	public int delete(String userId);
	public int update(User user);
	public List<User> getList();
	public int updatePwd(User user);
	public User getUserInfo(String userId);
}
