package com.ssafy.test.model.service.map;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.map.MapDao;
import com.ssafy.test.model.dto.map.MapDto;

@Service
public class MapServiceImpl implements MapService{
	private MapDao mapDao;
	
	public MapServiceImpl(MapDao mapDao) {
		this.mapDao = mapDao;
	}

	@Override
	public List<MapDto> getList(Map<String, Integer> listKind) {
		return mapDao.getList(listKind);
	}

	@Override
	public List<MapDto> getSearchList(String keyword) {
		return mapDao.getSearchList(keyword);
	}
	
}
