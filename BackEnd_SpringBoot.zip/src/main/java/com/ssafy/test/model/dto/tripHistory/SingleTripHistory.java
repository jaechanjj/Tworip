package com.ssafy.test.model.dto.tripHistory;

public class SingleTripHistory {
	private int id;
	private String tripName;
	private String userId;
	private String createdAt;
	private int status;
	private int contentId;
	private String firstImage;
	private String title;
	private String addr1;
	private int contentTypeId;
	private double latitude;
	private double longitude;
	
	public SingleTripHistory() {}
	
	public SingleTripHistory(int id, String tripName, String userId, String createdAt, int status, int contentId,
			String firstImage, String title, String addr1, int contentTypeId, double latitude, double longitude) {
		super();
		this.id = id;
		this.tripName = tripName;
		this.userId = userId;
		this.createdAt = createdAt;
		this.status = status;
		this.contentId = contentId;
		this.firstImage = firstImage;
		this.title = title;
		this.addr1 = addr1;
		this.contentTypeId = contentTypeId;
		this.latitude = latitude;
		this.longitude = longitude;
	}



	public double getLatitude() {
		return latitude;
	}


	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}


	public double getLongitude() {
		return longitude;
	}


	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTripName() {
		return tripName;
	}

	public void setTripName(String tripName) {
		this.tripName = tripName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public String getFirstImage() {
		return firstImage;
	}

	public void setFirstImage(String firstImage) {
		this.firstImage = firstImage;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public int getContentTypeId() {
		return contentTypeId;
	}

	public void setContentTypeId(int contentTypeId) {
		this.contentTypeId = contentTypeId;
	}

	@Override
	public String toString() {
		return "SingleTripHistory [id=" + id + ", tripName=" + tripName + ", userId=" + userId + ", createdAt="
				+ createdAt + ", status=" + status + ", contentId=" + contentId + ", firstImage=" + firstImage
				+ ", title=" + title + ", addr1=" + addr1 + ", contentTypeId=" + contentTypeId + ", latitude="
				+ latitude + ", longitude=" + longitude + "]";
	}
}
