package com.ssafy.test.model.dto.singlecomfirmplan;

import java.util.List;

public class SingleComfirmPlan {

	private int id;
	private String tripName;
	private String userId;
	private int contentId;
	private String createdAt;
	private int status;
	
	public SingleComfirmPlan() {};
	
	public SingleComfirmPlan(String tripName, String userId, int contentId) {
		this.tripName = tripName;
		this.userId = userId;
		this.contentId = contentId;
	}
	
	public SingleComfirmPlan(int id, String tripName, String userId, int contentId, String createdAt, int status) {
		this.id = id;
		this.tripName = tripName;
		this.userId = userId;
		this.contentId = contentId;
		this.createdAt = createdAt;
		this.status = status;
	}

	public String getTripName() {
		return tripName;
	}

	public void setTripName(String tripName) {
		this.tripName = tripName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "SingleComfirmPlan [id=" + id + ", tripName=" + tripName + ", userId=" + userId + ", contentId="
				+ contentId + ", createdAt=" + createdAt + ", status=" + status + "]";
	}
}
