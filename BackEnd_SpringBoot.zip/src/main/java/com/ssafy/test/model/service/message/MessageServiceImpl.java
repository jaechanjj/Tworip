package com.ssafy.test.model.service.message;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.message.MessageDao;
import com.ssafy.test.model.dto.message.MessageDto;

@Service
public class MessageServiceImpl implements MessageService {
	
	MessageDao messageDao;
	
	public MessageServiceImpl(MessageDao messageDao) {
		this.messageDao = messageDao;
	}

	@Override
	public List<MessageDto> getMessages(MessageDto message) {
		return messageDao.getMessage(message);
	}

	@Override
	public void send(MessageDto message) {
		messageDao.send(message);
	}

	@Override
	public List<String> people(String userId) {
		return messageDao.people(userId);
	}

}
