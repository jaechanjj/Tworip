package com.ssafy.test.model.service.board;

import com.ssafy.test.model.dto.board.BoardImg;

public interface BoardImgService {
	public int setImgUrl(BoardImg boardImg);
	public BoardImg getImgUrl(int boardId);
	public int deleteImg(int id);
}
