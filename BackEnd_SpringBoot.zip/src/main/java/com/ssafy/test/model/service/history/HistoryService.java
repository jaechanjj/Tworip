package com.ssafy.test.model.service.history;

import java.util.List;

import com.ssafy.test.model.dto.comfirmplan.ComfirmPlan;
import com.ssafy.test.model.dto.singlecomfirmplan.SingleComfirmPlan;
import com.ssafy.test.model.dto.tripHistory.SingleTripHistory;
import com.ssafy.test.model.dto.tripHistory.TripHistory;
import com.ssafy.test.model.dto.user.User;

public interface HistoryService {
	public List<TripHistory> getHistory(String userId);
	public void changeStatus(TripHistory targetContent);
	public List<TripHistory> getCurTrip(String userId);
	public List<TripHistory> search(TripHistory tripHistory);
}
