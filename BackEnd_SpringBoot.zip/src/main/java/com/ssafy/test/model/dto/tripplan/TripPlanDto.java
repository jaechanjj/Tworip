package com.ssafy.test.model.dto.tripplan;

public class TripPlanDto {
	
	int id;
	int contentId;
	String userId;
	
	public TripPlanDto() {}

	public TripPlanDto(int id, int contentId, String userId) {
		super();
		this.id = id;
		this.contentId = contentId;
		this.userId = userId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	
}
