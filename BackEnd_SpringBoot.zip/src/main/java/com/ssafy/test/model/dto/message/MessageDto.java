package com.ssafy.test.model.dto.message;

public class MessageDto {

	private int id;
	private String sendUser;
	private String recevieUser;
	private String message;
	
	public MessageDto() {}

	public MessageDto(int id, String sendUser, String recevieUser, String message) {
		super();
		this.id = id;
		this.sendUser = sendUser;
		this.recevieUser = recevieUser;
		this.message = message;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSendUser() {
		return sendUser;
	}

	public void setSendUser(String sendUser) {
		this.sendUser = sendUser;
	}

	public String getRecevieUser() {
		return recevieUser;
	}

	public void setRecevieUser(String recevieUser) {
		this.recevieUser = recevieUser;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "MessageDto [id=" + id + ", sendUser=" + sendUser + ", recevieUser=" + recevieUser + ", message="
				+ message + "]";
	}
	
	
}
