package com.ssafy.test.model.dao.chatGpt;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ChatGptDao {

}
