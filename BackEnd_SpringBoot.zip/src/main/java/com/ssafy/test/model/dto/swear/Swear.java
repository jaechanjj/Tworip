package com.ssafy.test.model.dto.swear;

public class Swear {

	private String fword;
	
	public Swear() {}

	public Swear(String fword) {
		super();
		this.fword = fword;
	}

	public String getFword() {
		return fword;
	}

	public void setFword(String fword) {
		this.fword = fword;
	}
}
