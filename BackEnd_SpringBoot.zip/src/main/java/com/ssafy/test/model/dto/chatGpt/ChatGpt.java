package com.ssafy.test.model.dto.chatGpt;

public class ChatGpt {

}
