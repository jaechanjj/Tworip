package com.ssafy.test.model.service.history;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.history.HistoryDao;
import com.ssafy.test.model.dto.comfirmplan.ComfirmPlan;
import com.ssafy.test.model.dto.map.MapDto;
import com.ssafy.test.model.dto.singlecomfirmplan.SingleComfirmPlan;
import com.ssafy.test.model.dto.tripHistory.SingleTripHistory;
import com.ssafy.test.model.dto.tripHistory.TripHistory;
import com.ssafy.test.model.dto.user.User;

@Service
public class HistoryServiceImpl implements HistoryService{
	
	HistoryDao historyDao;

	public HistoryServiceImpl(HistoryDao historyDao) {
		this.historyDao = historyDao;
	}

	@Override
	public List<TripHistory> getHistory(String userId) {
		List<SingleTripHistory> list = historyDao.getHistory(userId);
		List<TripHistory> historyList = new ArrayList<>();
		
		String tripName =  "";
		boolean isFirst = true;
		List<MapDto> contentList = new ArrayList<>();
		TripHistory tripHistory = new TripHistory();
		int id=1;
		
		for(SingleTripHistory l : list) {
			MapDto content = new MapDto(l.getContentId(), l.getFirstImage(), l.getTitle(), l.getAddr1(), l.getContentTypeId(), l.getLatitude(), l.getLongitude() );
			
			if(!tripName.equals(l.getTripName())) {	
				if(isFirst) {
					isFirst = false;
					contentList.add(content);
				}
				else {
					// 제일 처음 데이터가 아니라면 기존에 저장한 데이터를 list에 추가
					tripHistory.setContent(contentList);
					historyList.add(tripHistory);
					
					id++;
					tripHistory = new TripHistory();
					contentList = new ArrayList<>();
					contentList.add(content);
				}
				
				tripName = l.getTripName();
			} else {
				contentList.add(content);
			}
			
			tripHistory.setId(id);
			tripHistory.setTripName(l.getTripName());
			tripHistory.setUserId(l.getUserId());
			tripHistory.setStatus(l.getStatus());
			tripHistory.setCreatedAt(l.getCreatedAt());
		}
		
		// 마지막에 저장된 데이터 추가
		tripHistory.setContent(contentList);
		historyList.add(tripHistory);
		
		return historyList;
	}

	@Override
	public void changeStatus(TripHistory targetContent) {
		historyDao.changeStatus(targetContent);
	}

	public List<TripHistory> search(TripHistory tripHistory) {
		return historyDao.search(tripHistory);
	}

	@Override
	public List<TripHistory> getCurTrip(String userId) {
		List<SingleTripHistory> list = historyDao.getCurTrip(userId);
		List<TripHistory> historyList = new ArrayList<>();
		
		String tripName =  "";
		boolean isFirst = true;
		List<MapDto> contentList = new ArrayList<>();
		TripHistory tripHistory = new TripHistory();
		int id=1;
		
		for(SingleTripHistory l : list) {
			MapDto content = new MapDto(l.getContentId(), l.getFirstImage(), l.getTitle(), l.getAddr1(), l.getContentTypeId(), l.getLatitude(), l.getLongitude() );
			
			if(!tripName.equals(l.getTripName())) {	
				if(isFirst) {
					isFirst = false;
					contentList.add(content);
				}
				else {
					// 제일 처음 데이터가 아니라면 기존에 저장한 데이터를 list에 추가
					tripHistory.setContent(contentList);
					historyList.add(tripHistory);
					
					id++;
					tripHistory = new TripHistory();
					contentList = new ArrayList<>();
					contentList.add(content);
				}
				
				tripName = l.getTripName();
			} else {
				contentList.add(content);
			}
			
			tripHistory.setId(id);
			tripHistory.setTripName(l.getTripName());
			tripHistory.setUserId(l.getUserId());
			tripHistory.setStatus(l.getStatus());
			tripHistory.setCreatedAt(l.getCreatedAt());
		}
		
		// 마지막에 저장된 데이터 추가
		tripHistory.setContent(contentList);
		historyList.add(tripHistory);
		
		return historyList;
	}


	
}
