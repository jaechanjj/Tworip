package com.ssafy.test.model.service.chatGpt;

public class ChatGptServiceImpl implements ChatGptService{

}
