package com.ssafy.test.model.dao.board;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.board.Board;
import com.ssafy.test.model.dto.swear.Swear;

@Mapper
public interface BoardDao {

	int regist(Board board);
	List<Board> listarticle();
	Board view(String articleNo);
	int delete(int articleNo);
	int update(Board board);
	void updateHit(int articleNo);
	ArrayList<Swear> getSwears();
	Board detail(int articleNo);
	
}
