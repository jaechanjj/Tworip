package com.ssafy.test.model.service.talk;

import java.util.List;

import com.ssafy.test.model.dto.talk.Talk;

public interface TalkService {
	public List<Talk> getTalkList();
	public int registTalk(Talk talk);
	public int deleteTalk(int talkId);
	public int updateTalk(Talk talk);
	public Talk getDetailTalk(int talkId);
}
