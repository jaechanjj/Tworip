package com.ssafy.test.model.dao.board;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.board.BoardComment;

@Mapper
public interface BoardCommentDao {
	int postComment(BoardComment boardComment);
	int putComment(BoardComment boardComment);
	int deleteComment(int id);
	List<BoardComment> getCommentList(int board_id);
}
