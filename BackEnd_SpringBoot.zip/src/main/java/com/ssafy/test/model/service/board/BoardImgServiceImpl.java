package com.ssafy.test.model.service.board;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.board.BoardImgDao;
import com.ssafy.test.model.dto.board.BoardImg;

@Service
public class BoardImgServiceImpl implements BoardImgService{

	BoardImgDao boardImgDao;
	
	public BoardImgServiceImpl(BoardImgDao boardImgDao) {
		this.boardImgDao = boardImgDao;
	}

	@Override
	public int setImgUrl(BoardImg boardImg) {
		return boardImgDao.setImgUrl(boardImg);
	}

	@Override
	public BoardImg getImgUrl(int boardId) {
		return boardImgDao.getImgUrl(boardId);
	}

	@Override
	public int deleteImg(int id) {
		return boardImgDao.deleteImg(id);
	}

}
