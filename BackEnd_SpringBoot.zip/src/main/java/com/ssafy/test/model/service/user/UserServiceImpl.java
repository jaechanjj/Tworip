package com.ssafy.test.model.service.user;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.user.UserDao;
import com.ssafy.test.model.dto.user.User;

@Service
public class UserServiceImpl implements UserService{
	
	private UserDao userDao;
	
	public UserServiceImpl(UserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	public User login(String userId) {
		return userDao.login(userId);
	}

	@Override
	public int register(User user) {
		return userDao.register(user);
	}

	@Override
	public int delete(String userId) {
		return userDao.delete(userId);
	}

	@Override
	public int update(User user) {
		return userDao.update(user);
	}

	@Override
	public List<User> getList() {
		return userDao.getList();
	}

	@Override
	public int updatePwd(User user) {
		return userDao.updatePwd(user);
	}

	@Override
	public User getUserInfo(String userId) {
		return userDao.getUserInfo(userId);
	}

}
