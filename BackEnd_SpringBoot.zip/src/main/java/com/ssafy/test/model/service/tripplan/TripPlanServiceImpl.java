package com.ssafy.test.model.service.tripplan;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.tripplan.TripPlanDao;
import com.ssafy.test.model.dto.comfirmplan.ComfirmPlan;
import com.ssafy.test.model.dto.singlecomfirmplan.SingleComfirmPlan;
import com.ssafy.test.model.dto.tripplan.TripPlanDto;
import com.ssafy.test.model.dto.user.User;


@Service
public class TripPlanServiceImpl implements TripPlanServcie{


	public TripPlanDao tripPlanDao;
	
	public TripPlanServiceImpl(TripPlanDao tripPlanDao) {
		this.tripPlanDao=tripPlanDao;
	}
	
	@Override
	public int postPlan(TripPlanDto tripPlanDto) {
		return tripPlanDao.regist(tripPlanDto);
	}

	@Override
	public List<TripPlanDto> showList(String userId) {
		return tripPlanDao.showList(userId);
	}

	@Override
	public int remove(int id) {
		return tripPlanDao.remove(id);
	}

	@Override
	public List<String> getsamePlaceUser(String userId) {
		return tripPlanDao.getsamePlaceUser(userId);
	}

	@Override
	public int postOwnPlan(ComfirmPlan comfirmPlan) {
		
		int cnt =0;
		
		for(int i : comfirmPlan.getContentId()) {
			cnt++;
			SingleComfirmPlan tmp = new SingleComfirmPlan(comfirmPlan.getTripName(),comfirmPlan.getUserId(),i);
			tripPlanDao.postOwnPlan(tmp);
		}
		
		if(cnt==comfirmPlan.getContentId().size()) {
			return 1;
		}
		return 0;
	}
	
	

}
