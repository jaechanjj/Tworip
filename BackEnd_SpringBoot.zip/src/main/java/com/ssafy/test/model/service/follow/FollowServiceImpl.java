package com.ssafy.test.model.service.follow;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.follow.FollowDao;
import com.ssafy.test.model.dto.follow.Follow;
import com.ssafy.test.model.dto.follow.FollowRes;

@Service
public class FollowServiceImpl implements FollowService{
	
	FollowDao followDao;
	
	public FollowServiceImpl(FollowDao followDao) {
		this.followDao = followDao;
	}

	@Override
	public int reqFollow(Follow follow) {
		return followDao.reqFollow(follow);
	}

	@Override
	public Follow getReqFollow(Follow follow) {
		return followDao.getReqFollow(follow);
	}

	@Override
	public List<Follow> getUserFollow(String followee) {
		return followDao.getUserFollow(followee);
	}

	@Override
	public int acceptFollow(Follow follow) {
		return followDao.acceptFollow(follow);
	}

	@Override
	public int refuseFollow(Follow follow) {
		return followDao.refuseFollow(follow);
	}

	@Override
	public List<FollowRes> getUserFollowee(String followee) {
		return followDao.getUserFollowee(followee);
	}

	@Override
	public List<FollowRes> getUserFollower(String followee) {
		return followDao.getUserFollower(followee);
	}

	@Override
	public Follow followCheck(Follow follow) {
		return followDao.followCheck(follow);
	}

	@Override
	public List<FollowRes> getReqFolloee(String followee) {
		return followDao.getReqFolloee(followee);
	}

}
