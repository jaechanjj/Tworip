package com.ssafy.test.model.dto.tripplan;

public class OwnPlanDto {

}
