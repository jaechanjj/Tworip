package com.ssafy.test.model.dto.follow;

public class Follow {
	int id;
	String follower;
	String followee;
	
	public Follow() {}

	public Follow(int id, String follower, String followee) {
		this.id = id;
		this.follower = follower;
		this.followee = followee;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFollower() {
		return follower;
	}

	public void setFollower(String follower) {
		this.follower = follower;
	}

	public String getFollowee() {
		return followee;
	}

	public void setFollowee(String followee) {
		this.followee = followee;
	}

	@Override
	public String toString() {
		return "Follow [id=" + id + ", follower=" + follower + ", followee=" + followee + "]";
	}
}
