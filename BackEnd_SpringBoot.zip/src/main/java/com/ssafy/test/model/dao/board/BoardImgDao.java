package com.ssafy.test.model.dao.board;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.board.BoardImg;

@Mapper
public interface BoardImgDao {
	public int setImgUrl(BoardImg boardImg);
	public BoardImg getImgUrl(int boardId);
	public int deleteImg(int id);
}
