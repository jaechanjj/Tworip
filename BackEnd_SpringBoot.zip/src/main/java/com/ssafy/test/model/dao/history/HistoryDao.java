package com.ssafy.test.model.dao.history;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.singlecomfirmplan.SingleComfirmPlan;
import com.ssafy.test.model.dto.tripHistory.SingleTripHistory;
import com.ssafy.test.model.dto.tripHistory.TripHistory;
import com.ssafy.test.model.dto.user.User;

@Mapper
public interface HistoryDao {
	public List<SingleTripHistory> getHistory(String userId);
	public void changeStatus(TripHistory targetContent);
	public List<SingleTripHistory> getCurTrip(String userId);
	public List<TripHistory> search(TripHistory tripHistory);
}
