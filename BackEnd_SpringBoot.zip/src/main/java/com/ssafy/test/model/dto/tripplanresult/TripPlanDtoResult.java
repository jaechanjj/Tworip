package com.ssafy.test.model.dto.tripplanresult;

public class TripPlanDtoResult {

	int id;
	int contentId;
	int contentTypeId;
	String userId;
	String title;
	String addr1;
	String latitude;
	String longitude;
	String firstImage;
	
	
	public TripPlanDtoResult() {}


	public TripPlanDtoResult(int id, int contentId, int contentTypeId, String userId, String title, String addr1,
			String latitude, String longitude, String firstImage) {
		super();
		this.id = id;
		this.contentId = contentId;
		this.contentTypeId = contentTypeId;
		this.userId = userId;
		this.title = title;
		this.addr1 = addr1;
		this.latitude = latitude;
		this.longitude = longitude;
		this.firstImage = firstImage;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getContentId() {
		return contentId;
	}


	public void setContentId(int contentId) {
		this.contentId = contentId;
	}


	public int getContentTypeId() {
		return contentTypeId;
	}


	public void setContentTypeId(int contentTypeId) {
		this.contentTypeId = contentTypeId;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}


	public String getLatitude() {
		return latitude;
	}


	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}


	public String getLongitude() {
		return longitude;
	}


	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}


	public String getFirstImage() {
		return firstImage;
	}


	public void setFirstImage(String firstImage) {
		this.firstImage = firstImage;
	}


	@Override
	public String toString() {
		return "TripPlanDtoResult [id=" + id + ", contentId=" + contentId + ", contentTypeId=" + contentTypeId
				+ ", userId=" + userId + ", title=" + title + ", addr1=" + addr1 + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", firstImage=" + firstImage + "]";
	}


	

	
}
