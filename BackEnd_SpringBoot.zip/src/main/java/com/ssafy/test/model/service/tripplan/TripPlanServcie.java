package com.ssafy.test.model.service.tripplan;

import java.util.List;

import com.ssafy.test.model.dto.comfirmplan.ComfirmPlan;
import com.ssafy.test.model.dto.tripplan.TripPlanDto;
import com.ssafy.test.model.dto.user.User;

public interface TripPlanServcie {

	int postPlan(TripPlanDto tripPlanDto);
	List<TripPlanDto> showList(String userId);
	int remove(int id);
	List<String> getsamePlaceUser(String userId);
	int postOwnPlan(ComfirmPlan comfirmPlan);

}
