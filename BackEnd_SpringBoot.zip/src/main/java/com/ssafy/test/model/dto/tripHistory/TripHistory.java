package com.ssafy.test.model.dto.tripHistory;

import java.util.List;

import com.ssafy.test.model.dto.map.MapDto;

public class TripHistory {
	private int id;
	private String tripName;
	private String userId;
	private List<MapDto> content;
	private String createdAt;
	private int status;
	
	public TripHistory() {}

	public TripHistory(int id, String tripName, String userId, List<MapDto> content, String createdAt,
			int status) {
		this.id = id;
		this.tripName = tripName;
		this.userId = userId;
		this.content = content;
		this.createdAt = createdAt;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTripName() {
		return tripName;
	}

	public void setTripName(String tripName) {
		this.tripName = tripName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<MapDto> getContent() {
		return content;
	}

	public void setContent(List<MapDto> content) {
		this.content = content;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "TripHistory [id=" + id + ", tripName=" + tripName + ", userId=" + userId + ", content=" + content
				+ ", createdAt=" + createdAt + ", status=" + status + "]";
	}
}
