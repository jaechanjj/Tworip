package com.ssafy.test.model.dao.board;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.board.BoardLike;
import com.ssafy.test.model.dto.board.BoardLikeResponse;

@Mapper
public interface BoardLikeDao {
	int postLike(BoardLike boardLike);
	int deleteLike(BoardLike boardLike);
	List<BoardLikeResponse> getBoardLikeList(String userId);
	BoardLike getBoardLike(BoardLike boardLike);
}
