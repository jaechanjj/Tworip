package com.ssafy.test.model.dao.talk;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.test.model.dto.talk.Talk;

@Mapper
public interface TalkDao {
	public List<Talk> getTalkList();
	public int registTalk(Talk talk);
	public int deleteTalk(int talkId);
	public int updateTalk(Talk talk);
	public Talk getDetailTalk(int talkId);
}
