package com.ssafy.test.model.dto.board;

public class BoardLikeResponse {
	int id;
	String userId;
	int articleNo;
	private String title;
	private String content;
	private int hit;
	private String createdAt;
	
	
	public BoardLikeResponse() {}

	public BoardLikeResponse(int id, String userId, int articleNo, String title, String content, int hit,
			String createdAt) {
		this.id = id;
		this.userId = userId;
		this.articleNo = articleNo;
		this.title = title;
		this.content = content;
		this.hit = hit;
		this.createdAt = createdAt;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getArticleNo() {
		return articleNo;
	}

	public void setArticleNo(int articleNo) {
		this.articleNo = articleNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getHit() {
		return hit;
	}

	public void setHit(int hit) {
		this.hit = hit;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	@Override
	public String toString() {
		return "BoardLikeResponse [id=" + id + ", userId=" + userId + ", articleNo=" + articleNo + ", title=" + title
				+ ", content=" + content + ", hit=" + hit + ", createdAt=" + createdAt + "]";
	}
}
