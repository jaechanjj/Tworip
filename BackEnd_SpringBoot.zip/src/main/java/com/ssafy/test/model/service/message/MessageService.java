package com.ssafy.test.model.service.message;

import java.util.List;

import com.ssafy.test.model.dto.message.MessageDto;

public interface MessageService {

	List<MessageDto> getMessages(MessageDto message);
	void send(MessageDto message);
	List<String> people(String userId);


}
