package com.ssafy.test.model.service.board;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.board.BoardLikeDao;
import com.ssafy.test.model.dto.board.BoardLike;
import com.ssafy.test.model.dto.board.BoardLikeResponse;

@Service
public class BoardLikeServiceImpl implements BoardLikeService {

	BoardLikeDao boardLikeDao;
	
	public BoardLikeServiceImpl(BoardLikeDao boardLikeDao) {
		this.boardLikeDao = boardLikeDao;
	}

	@Override
	public int postLike(BoardLike boardLike) {
		return boardLikeDao.postLike(boardLike);
	}

	@Override
	public int deleteLike(BoardLike boardLike) {
		return boardLikeDao.deleteLike(boardLike);
	}

	@Override
	public List<BoardLikeResponse> getBoardLikeList(String userId) {
		return boardLikeDao.getBoardLikeList(userId);
	}

	@Override
	public BoardLike getBoardLike(BoardLike boardLike) {
		return boardLikeDao.getBoardLike(boardLike);
	}

}
