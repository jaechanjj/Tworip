package com.ssafy.test.model.dto.talk;

public class Talk {
	private int articleNo;
	private String title;
	private String content;
	private String createdAt;
	private String userId;
	
	public Talk() {
	}

	public Talk(int articleNo, String title, String content, String createdAt, String userId) {
		super();
		this.articleNo = articleNo;
		this.title = title;
		this.content = content;
		this.createdAt = createdAt;
		this.userId = userId;
	}

	public int getArticleNo() {
		return articleNo;
	}

	public void setArticleNo(int articleNo) {
		this.articleNo = articleNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Talk [articleNo=" + articleNo + ", title=" + title + ", content=" + content + ", createdAt=" + createdAt
				+ ", userId=" + userId + "]";
	}
}
