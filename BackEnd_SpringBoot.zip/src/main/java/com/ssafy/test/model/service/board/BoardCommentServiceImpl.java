package com.ssafy.test.model.service.board;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.test.model.dao.board.BoardCommentDao;
import com.ssafy.test.model.dto.board.BoardComment;

@Service
public class BoardCommentServiceImpl implements BoardCommentService{
	BoardCommentDao boardCommentDao;
	
	public BoardCommentServiceImpl(BoardCommentDao boardCommentDao) {
		this.boardCommentDao = boardCommentDao;
	}

	@Override
	public int postComment(BoardComment boardComment) {
		return boardCommentDao.postComment(boardComment);
	}

	@Override
	public int putComment(BoardComment boardComment) {
		return boardCommentDao.putComment(boardComment);
	}

	@Override
	public int deleteComment(int id) {
		return boardCommentDao.deleteComment(id);
	}

	@Override
	public List<BoardComment> getCommentList(int board_id) {
		return boardCommentDao.getCommentList(board_id);
	}
}
