package com.ssafy.test.model.dto.user;

public class User {
	String userId;
	String userName;
	String userPass;
	String emailid;
	String domain;
	String salt;
	
	public User() {}

	public User(String userId, String userPass) {
		this.userId = userId;
		this.userPass = userPass;
	}
	
	public User(String userId) {
		this.userId = userId;
	}
	

	public User(String userId, String userName, String userPass, String emailid, String domain, String salt) {
		this.userId = userId;
		this.userName = userName;
		this.userPass = userPass;
		this.emailid = emailid;
		this.domain = domain;
		this.salt = salt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPass=" + userPass + ", emailid=" + emailid
				+ ", domain=" + domain + ", salt=" + salt + "]";
	}
}
