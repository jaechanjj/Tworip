package com.ssafy.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pjt06Buk041104Application {

	public static void main(String[] args) {
		SpringApplication.run(Pjt06Buk041104Application.class, args);
	}

}
